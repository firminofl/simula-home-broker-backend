const Message = {
    UNABLE_TO_FIND_SERVER: `Impossível alcançar o servidor que fornece a API.`
}

module.exports = Message;